package com.joelcodes.studentsystem.controller;

public class AuthController {
}
